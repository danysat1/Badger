import java.util.*;
import ecs100.*;

public class CoreSample {
    private String ID;
    private String date;
    private double depth;
    private Location location;

    public CoreSample(){}

    public void setID(String ID){this.ID = ID;}
    public String getID(){return this.ID;}

    public void setDate(String date){this.date= date;}
    public String getDate(){return this.date;}

    public void setDepth(double depth){this.depth = depth;}
    public double getDepth(){return this.depth;}

    public void setLocation(Location: loc){}

    public void printDetails(){
    }

}
